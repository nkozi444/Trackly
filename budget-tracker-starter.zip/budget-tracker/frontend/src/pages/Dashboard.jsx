import { useEffect, useState } from "react";
import api from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ amount: "", type: "expense", category_id: "", description: "" });

  useEffect(() => {
    loadTransactions();
    loadCategories();
  }, []);

  async function loadTransactions() {
    const res = await api.get("/transactions");
    setTransactions(res.data);
  }

  async function loadCategories() {
    const res = await api.get("/categories");
    setCategories(res.data);
  }

  async function handleAdd(e) {
    e.preventDefault();
    await api.post("/transactions", form);
    setForm({ amount: "", type: "expense", category_id: "", description: "" });
    loadTransactions();
  }

  async function handleDelete(id) {
    await api.delete(`/transactions/${id}`);
    loadTransactions();
  }

  const totalIncome = transactions.filter((t) => t.type === "income").reduce((s, t) => s + Number(t.amount), 0);
  const totalExpense = transactions.filter((t) => t.type === "expense").reduce((s, t) => s + Number(t.amount), 0);

  return (
    <div style={{ maxWidth: 700, margin: "40px auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <h2>Welcome, {user?.email}</h2>
        <button onClick={logout}>Log out</button>
      </div>

      <div style={{ display: "flex", gap: 20, margin: "20px 0" }}>
        <div>Income: ₱{totalIncome.toFixed(2)}</div>
        <div>Expenses: ₱{totalExpense.toFixed(2)}</div>
        <div>Balance: ₱{(totalIncome - totalExpense).toFixed(2)}</div>
      </div>

      <form onSubmit={handleAdd} style={{ marginBottom: 20 }}>
        <input
          type="number"
          placeholder="Amount"
          value={form.amount}
          onChange={(e) => setForm({ ...form, amount: e.target.value })}
          required
        />
        <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
          <option value="expense">Expense</option>
          <option value="income">Income</option>
        </select>
        <select
          value={form.category_id}
          onChange={(e) => setForm({ ...form, category_id: e.target.value })}
        >
          <option value="">No category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <input
          type="text"
          placeholder="Description"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />
        <button type="submit">Add</button>
      </form>

      <table width="100%" cellPadding={6}>
        <thead>
          <tr>
            <th align="left">Date</th>
            <th align="left">Type</th>
            <th align="left">Category</th>
            <th align="left">Description</th>
            <th align="right">Amount</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((t) => (
            <tr key={t.id}>
              <td>{new Date(t.transaction_date).toLocaleDateString()}</td>
              <td>{t.type}</td>
              <td>{t.category_name || "-"}</td>
              <td>{t.description || "-"}</td>
              <td align="right">₱{Number(t.amount).toFixed(2)}</td>
              <td>
                <button onClick={() => handleDelete(t.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
